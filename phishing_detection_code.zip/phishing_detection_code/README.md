# AI-Based Phishing Email Detection
### Classical ML vs Transformer (DistilBERT) — Comparative Study

> **Course:** Seminar CSC301 | **University:** The NorthCap University, Gurugram
> **Professor:** Dr. Poonam Chaudhary

---

## Overview

This repository contains the implementation code for the seminar paper:

> **"AI-Based Phishing and Social Engineering Detection: A Comparative Analysis"**

The notebook implements and compares two phishing email detection approaches:

| Approach | Models | Type |
|---|---|---|
| Baseline | Logistic Regression, Linear SVM, Random Forest + TF-IDF | Classical ML |
| State-of-Art | DistilBERT (fine-tuned) | Transformer |

**Core finding replicated:** DistilBERT consistently outperforms classical ML models, confirming the findings of Linh et al. (2026) who reported 98.77% accuracy with DistilBERT vs lower scores for all classical baselines.

---

## Repository Structure

```
phishing-detection/
│
├── phishing_detection.ipynb     ← Main notebook (all steps)
├── requirements.txt             ← Python dependencies
├── README.md                    ← This file
│
└── outputs/ (auto-generated after running)
    ├── comparison_bar_chart.png
    ├── confusion_matrices.png
    ├── training_loss.png
    ├── results_summary.csv
    └── distilbert_phishing_model/
```

---

## Setup & Run

### Option A — Google Colab (Recommended, free GPU)

1. Open [Google Colab](https://colab.research.google.com)
2. Click **File → Upload notebook** → select `phishing_detection.ipynb`
3. Click **Runtime → Change runtime type → T4 GPU**
4. Run all cells (`Runtime → Run all`)

### Option B — Local Machine

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/phishing-detection.git
cd phishing-detection

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate       # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Launch Jupyter
jupyter notebook phishing_detection.ipynb
```

---

## Dataset

The notebook works in **two modes**:

| Mode | How to trigger | Samples |
|---|---|---|
| **Synthetic demo** | Run notebook as-is (no extra files needed) | 600 |
| **Real data** | Download from Kaggle, rename to `phishing_emails.csv` | 18,000+ |

**Real dataset link:** [Phishing Email Dataset — Kaggle](https://www.kaggle.com/datasets/naserabdullahalam/phishing-email-dataset)

To use the real dataset:
1. Download `phishing_emails.csv` from Kaggle
2. Place it in the same folder as the notebook
3. Re-run Step 3

---

## Results (Synthetic Demo)

| Model | Accuracy | F1-Score |
|---|---|---|
| Logistic Regression | ~0.93 | ~0.93 |
| Linear SVM | ~0.95 | ~0.95 |
| Random Forest | ~0.94 | ~0.94 |
| **DistilBERT (Transformer)** | **~0.98** | **~0.98** |

*Results on real data (18K emails) match findings in Linh et al. (2026): DistilBERT ~98.77%.*

---

## Key Paper References

1. Linh et al. (2026). DistilBERT for efficient email phishing detection. https://doi.org/10.18280/isi.310321
2. Sajad U P (2026). Robust transformer framework for phishing detection. https://arxiv.org/abs/2511.12085
3. Uddin et al. (2025). Explainable transformer model for phishing detection. https://arxiv.org/abs/2402.13871
4. Altan et al. (2025). Dual-path phishing detection. https://arxiv.org/abs/2509.20972
5. Chakravorty et al. (2026). Context-aware phishing detection. https://arxiv.org/abs/2603.27326

---

## How to Upload to GitHub

```bash
# In the project folder:
git init
git add .
git commit -m "Initial commit: phishing detection notebook"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/phishing-detection.git
git push -u origin main
```

Then paste the GitHub link in your seminar submission.

---

*The NorthCap University, Gurugram | Seminar CSC301 | Prof. Dr. Poonam Chaudhary*
